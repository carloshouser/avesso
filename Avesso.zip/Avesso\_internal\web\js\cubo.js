/* Gerador de Cubos - Etapa 3: construtor de 4 areas + tabela com multiplas
   metricas, subtotais, formatacao condicional e ordenacao.
   A agregacao e feita no servidor (pandas); aqui cuidamos da interacao. */
(function () {
  "use strict";
  const $ = (id) => document.getElementById(id);

  const fmtNum = new Intl.NumberFormat("pt-BR", { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  const fmtInt = new Intl.NumberFormat("pt-BR", { maximumFractionDigits: 0 });
  const fmt = (v, formato) => (v === null || v === undefined) ? "—" : (formato === "inteiro" ? fmtInt : fmtNum).format(v);

  // Rotulos explicativos: a pessoa escolhe a operacao ja vendo o que ela faz,
  // evitando o classico "Contagem" (conta registros) confundido com "Soma".
  const AGGS = [["soma", "Soma (soma os valores)"],
                ["media", "Média (valor médio)"],
                ["contagem", "Contagem (nº de registros)"],
                ["contagem_distinta", "Contagem distinta (valores únicos)"],
                ["minimo", "Mínimo (menor valor)"],
                ["maximo", "Máximo (maior valor)"]];

  // Operacoes de metrica calculada (conta entre duas metricas).
  const OPS_CALC = [["divisao", "÷ Divisão (A ÷ B)"], ["multiplicacao", "× Multiplicação (A × B)"],
                    ["soma", "+ Soma (A + B)"], ["subtracao", "− Subtração (A − B)"]];
  const SIMBOLO_OP = { divisao: "÷", multiplicacao: "×", soma: "+", subtracao: "−" };

  const state = {
    id: null, campos: [], mapa: {},
    zonas: { filtros: [], colunas: [], linhas: [], metricas: [] },
    ordenacao: { por: "rotulo", direcao: "asc", col: null },
    ultimo: null,
    fonte: null,        // de onde os dados vieram (caminho + config + esquema)
    ultimaCarga: null,  // quando os dados foram lidos pela ultima vez
  };

  function toast(m) { if (window.__toast) window.__toast(m); }
  // Mensagem real de um erro (para sempre mostrar o que aconteceu).
  function det(e) { return e && e.message ? e.message : String(e); }

  let chartInst = null;
  const PALETA = ["#2563eb", "#0f9d58", "#f59e0b", "#7c3aed", "#ef4444", "#0891b2",
                  "#db2777", "#65a30d", "#ea580c", "#4f46e5", "#0d9488", "#b45309"];

  /* ---------------- cenario inicial ---------------- */
  function cenarioExemplo() {
    const dims = state.campos.filter((c) => c.papel === "dimensao");
    const mes = dims.find((c) => c.derivado && /\(Mes\)$/.test(c.nome));
    const plano = dims.filter((c) => !c.derivado && c.tipo !== "data");
    const mets = state.campos.filter((c) => c.papel === "metrica");
    const pura = mets.filter((c) => c.papel_original === "metrica");
    const met1 = pura[0] || mets[0];
    const met2 = mets.find((c) => c !== met1);
    state.zonas = {
      filtros: [],
      colunas: mes ? [mes.nome] : [],
      linhas: plano[0] ? [plano[0].nome] : [],
      metricas: [met1 && { campo: met1.nome, agg: "soma" }, met2 && { campo: met2.nome, agg: "soma" }].filter(Boolean),
    };
    state.ordenacao = { por: "rotulo", direcao: "asc", col: null };
  }

  /* ---------------- API publica ---------------- */
  window.iniciarCubo = function (dados, fonte) {
    state.id = dados.id;
    state.campos = dados.campos || [];
    state.mapa = {};
    state.campos.forEach((c) => (state.mapa[c.nome] = c));
    state.fonte = fonte || null;
    marcarCarga();
    cenarioExemplo();
    sincronizar();
  };

  /* ---------------- salvar / abrir / atualizar o cubo ---------------- */
  function fmtDataHora(d) {
    return d.toLocaleString("pt-BR", {
      day: "2-digit", month: "2-digit", year: "numeric", hour: "2-digit", minute: "2-digit",
    });
  }

  function marcarCarga() {
    state.ultimaCarga = new Date();
    renderCargaInfo();
  }

  function renderCargaInfo() {
    const el = $("cargaInfo");
    if (!el) return;
    el.textContent = state.ultimaCarga ? "Última carga: " + fmtDataHora(state.ultimaCarga) : "";
  }

  // Le os dados da "fonte" (caminho + config + esquema) no servidor. Atualiza
  // id/campos/mapa. Retorna true se deu certo. E a "carga" propriamente dita.
  async function carregarFonte(fonte) {
    if (!fonte) { toast("Este cubo não tem uma fonte de dados salva."); return false; }
    // monta o corpo conforme a origem: arquivo CSV ou consulta a um banco
    const ehBanco = fonte.tipo === "banco" || fonte.tipo === "mysql"; // "mysql" = compat antiga
    let corpo;
    if (ehBanco) {
      const motor = fonte.motor || "mysql";
      const authWin = motor === "sqlserver" && fonte.conexao && fonte.conexao.auth === "windows";
      if (!authWin && (!fonte.conexao || !fonte.conexao.senha)) {
        toast("Informe a senha do banco para recarregar os dados."); return false;
      }
      corpo = { fonte_banco: { motor, conexao: fonte.conexao, sql: fonte.sql }, esquema: fonte.esquema };
    } else {
      if (!fonte.caminho) { toast("Este cubo não tem uma fonte de dados salva."); return false; }
      corpo = { caminho: fonte.caminho, config: fonte.config, esquema: fonte.esquema };
    }
    try {
      const r = await fetch("/api/carregar", {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify(corpo),
      });
      const res = await r.json();
      if (!res.ok) {
        const padrao = ehBanco
          ? "Não foi possível executar a consulta no banco."
          : "Não foi possível ler os dados (o arquivo ainda existe nesse caminho?).";
        toast(res.erro || padrao); return false;
      }
      state.id = res.id;
      state.campos = res.campos || [];
      state.mapa = {};
      state.campos.forEach((c) => (state.mapa[c.nome] = c));
      return true;
    } catch (e) { toast("Erro de comunicação ao ler os dados: " + det(e)); return false; }
  }

  function mostrarCubo() {
    $("viewImport")?.classList.add("oculto");
    $("viewCubo")?.classList.remove("oculto");
    window.scrollTo(0, 0);
  }

  // Sugere um nome de arquivo a partir do que esta em Linhas (ex.: "cubo por Produto").
  function sugereNome() {
    const r = state.zonas.linhas || [];
    const base = r.length ? "cubo por " + r.join(" e ") : "meu cubo";
    return base.replace(/[\\/:*?"<>|]/g, "").trim().slice(0, 60) + ".cubo";
  }

  async function salvarCubo() {
    if (!state.fonte) { toast("Importe os dados primeiro para poder salvar o cubo."); return; }
    // Segurança: nunca grava a senha do banco em disco. Ao reabrir, o app pede
    // a senha de novo. Os demais dados da conexão (tipo, servidor, usuário,
    // banco, SQL) ficam salvos para facilitar.
    let fonteSalvar = state.fonte;
    if (state.fonte.tipo === "banco" || state.fonte.tipo === "mysql") {
      fonteSalvar = { ...state.fonte, conexao: { ...state.fonte.conexao, senha: "" } };
    }
    const obj = {
      versao: 1,
      app: "Gerador de Cubos",
      salvo_em: new Date().toISOString(),
      fonte: fonteSalvar,
      cubo: { zonas: state.zonas, ordenacao: state.ordenacao },
    };
    const json = JSON.stringify(obj, null, 2);
    const nome = sugereNome();

    // No app desktop: abre o "Salvar como" do Windows (escolhe NOME e PASTA) e
    // grava direto, devolvendo o caminho para a gente mostrar onde foi.
    const api = window.pywebview && window.pywebview.api && window.pywebview.api.salvar_cubo;
    if (api) {
      try {
        const res = await window.pywebview.api.salvar_cubo(json, nome);
        if (res && res.ok) toast("Cubo salvo em: " + res.caminho);
        else if (res && res.cancelado) { /* a pessoa cancelou — nao faz nada */ }
        else toast("Não foi possível salvar: " + ((res && res.erro) || "erro desconhecido") + ".");
      } catch (e) { toast("Não foi possível salvar o cubo: " + det(e)); }
      return;
    }

    // Fora do app (navegador): pergunta o nome e baixa na pasta de Downloads.
    let nomeArq = (window.prompt("Dê um nome para o arquivo do cubo:", nome) || "").trim();
    if (!nomeArq) return;
    if (!/\.(cubo|json)$/i.test(nomeArq)) nomeArq += ".cubo";
    const blob = new Blob([json], { type: "application/json" });
    const a = document.createElement("a");
    a.href = URL.createObjectURL(blob);
    a.download = nomeArq;
    document.body.appendChild(a); a.click(); a.remove(); URL.revokeObjectURL(a.href);
    toast("Cubo salvo na pasta de Downloads como “" + nomeArq + "”.");
  }

  // Exposto para o app.js (botao "Abrir cubo salvo" da tela de importacao).
  window.__abrirCubo = function (file) {
    const nome = (file && file.name) || "";
    const fr = new FileReader();
    fr.onload = () => {
      let obj;
      try { obj = JSON.parse(fr.result); } catch (e) { toast("Arquivo de cubo inválido: " + det(e)); return; }
      aplicarCuboSalvo(obj, nome);
    };
    fr.onerror = () => toast("Não foi possível ler o arquivo.");
    fr.readAsText(file);
  };

  async function aplicarCuboSalvo(obj, nome) {
    if (!obj || !obj.fonte || !obj.cubo) { toast("Arquivo de cubo inválido."); return; }
    let fonte = obj.fonte;
    if (fonte.tipo === "mysql") fonte = { ...fonte, tipo: "banco", motor: "mysql" }; // compat antiga
    // Cubo de fonte de banco: a senha não foi salva — pede antes de reconectar.
    // (Autenticação do Windows não tem senha: reconecta direto.)
    if (fonte.tipo === "banco") {
      const authWin = fonte.motor === "sqlserver" && fonte.conexao && fonte.conexao.auth === "windows";
      if (!authWin) {
        const senha = await pedirSenhaBanco(fonte);
        if (senha === null) return;                // a pessoa cancelou
        fonte = { ...fonte, conexao: { ...fonte.conexao, senha } };
      }
    }
    const ok = await carregarFonte(fonte);         // recarrega os dados da fonte salva
    if (!ok) return;
    state.fonte = fonte;
    state.zonas = obj.cubo.zonas || { filtros: [], colunas: [], linhas: [], metricas: [] };
    state.ordenacao = obj.cubo.ordenacao || { por: "rotulo", direcao: "asc", col: null };
    mostrarCubo();
    marcarCarga();
    sincronizar();
    toast("Cubo" + (nome ? " “" + nome + "”" : "") + " carregado.");
  }

  // Fecha ao clicar FORA do modal, mas só quando o clique começou E terminou no
  // fundo. Evita que selecionar texto num campo e arrastar o mouse para fora
  // feche a janela sem querer.
  function fecharAoClicarFora(fundo, aoFechar) {
    let baixouNoFundo = false;
    fundo.addEventListener("mousedown", (e) => { baixouNoFundo = e.target === fundo; });
    fundo.addEventListener("click", (e) => {
      if (e.target === fundo && baixouNoFundo) aoFechar();
    });
  }

  // Pede a senha do banco ao reabrir um cubo salvo (a senha nunca vai para o
  // arquivo). Devolve a senha digitada, ou null se a pessoa cancelar.
  function pedirSenhaBanco(fonte) {
    const NOMES = { mysql: "MySQL", sqlserver: "SQL Server" };
    return new Promise((resolve) => {
      const c = fonte.conexao || {};
      const nomeBanco = NOMES[fonte.motor] || "banco de dados";
      const html = `<div class="modal-fundo" id="modalSenha"><div class="modal">
        <h3>&#128279; Reconectar ao ${esc(nomeBanco)}</h3>
        <p class="my-sub">Este cubo veio de uma consulta ${esc(nomeBanco)}. Por segurança, a senha
        não é guardada no arquivo — digite-a para reconectar e reabrir.</p>
        <div class="my-ctx">
          <span><b>Tipo</b> ${esc(nomeBanco)}</span>
          <span><b>Servidor</b> ${esc(c.host || "")}${c.porta ? ":" + esc(c.porta) : ""}</span>
          <span><b>Usuário</b> ${esc(c.usuario || "—")}</span>
          <span><b>Banco</b> ${esc(c.banco || "—")}</span>
        </div>
        <label class="my-lab">Senha<input id="psSenha" type="password" placeholder="•••••"></label>
        <div class="modal-acoes">
          <button class="btn" id="psCancelar">Cancelar</button>
          <button class="btn primario" id="psOk">Reconectar</button>
        </div>
      </div></div>`;
      document.body.insertAdjacentHTML("beforeend", html);
      const fundo = $("modalSenha");
      const fechar = (val) => { fundo.remove(); resolve(val); };
      fecharAoClicarFora(fundo, () => fechar(null));
      $("psCancelar").onclick = () => fechar(null);
      $("psOk").onclick = () => fechar($("psSenha").value);
      $("psSenha").addEventListener("keydown", (e) => { if (e.key === "Enter") fechar($("psSenha").value); });
      $("psSenha").focus();
    });
  }

  // Botao "Atualizar dados": rele a fonte (arquivo OU MySQL) e recalcula.
  async function atualizarDados() {
    if (!state.fonte) { toast("Não há dados para atualizar."); return; }
    const ok = await carregarFonte(state.fonte);
    if (!ok) return;
    marcarCarga();
    sincronizar();   // re-renderiza (valores de filtro atualizados) e recalcula
    toast("Dados atualizados.");
  }

  /* ---------------- sincronizar DOM + recalcular ---------------- */
  function dimensaoEmUso(nome) {
    return state.zonas.linhas.includes(nome) || state.zonas.colunas.includes(nome)
      || state.zonas.filtros.some((f) => f.campo === nome);
  }

  function chip(texto, extraHtml, attrs) {
    const a = Object.entries(attrs || {}).map(([k, v]) => `${k}="${v}"`).join(" ");
    return `<span class="chip" draggable="true" ${a}>${extraHtml || ""}<span class="chip-txt">${esc(texto)}</span>`
      + `<button class="chip-x" title="remover">&times;</button></span>`;
  }

  function sincronizar() {
    // palette
    const pal = state.campos.map((c) => {
      const ehMet = c.papel === "metrica";
      const usada = c.papel === "dimensao" && dimensaoEmUso(c.nome);
      const cls = "chip palette" + (ehMet ? " met" : "") + (usada ? " usada" : "");
      const sig = ehMet ? '<span class="chip-sig">Σ</span>' : "";
      return `<span class="${cls}" draggable="true" data-campo="${esc(c.nome)}" data-papel="${c.papel}">`
        + `${sig}<span class="chip-txt">${esc(c.nome)}</span></span>`;
    }).join("");
    $("zonaCampos").innerHTML = pal || '<span class="dica">—</span>';

    renderZona("filtros", state.zonas.filtros.map((f, i) => {
      const n = (f.valores || []).length;
      const info = n ? `<span class="chip-info">${n} excl.</span>` : "";
      return chip(f.campo, info, { "data-i": i, "data-zona": "filtros" });
    }));
    renderZona("colunas", state.zonas.colunas.map((c, i) => chip(c, "", { "data-i": i, "data-zona": "colunas" })));
    renderZona("linhas", state.zonas.linhas.map((c, i) => chip(c, "", { "data-i": i, "data-zona": "linhas" })));
    renderZona("metricas", state.zonas.metricas.map((m, i) => {
      if (m.tipo === "calculada") {
        const expr = m.formula ? formulaTexto(m.formula)
          : (m.a ? `${m.a.campo} ${OP_SIMB[OP_NOME_SIMB[m.op]] || "?"} ${m.b.campo}` : "(fórmula)");
        const nome = m.rotulo || expr;
        const dica = nome === expr ? expr : nome + " = " + expr;
        return `<span class="chip met calc" draggable="true" data-i="${i}" data-zona="metricas" title="${esc(dica)}">`
          + `<span class="chip-sig calc-sig">&fnof;</span><span class="chip-txt">${esc(nome)}</span>`
          + `<button class="chip-edit" data-i="${i}" title="editar">&#9998;</button>`
          + `<button class="chip-x" title="remover">&times;</button></span>`;
      }
      const sel = `<select class="chip-agg" data-i="${i}">` +
        AGGS.map(([v, l]) => `<option value="${v}" ${v === m.agg ? "selected" : ""}>${l}</option>`).join("") + "</select>";
      return `<span class="chip met" draggable="true" data-i="${i}" data-zona="metricas">${sel}`
        + `<span class="chip-txt">${esc(m.campo)}</span><button class="chip-x" title="remover">&times;</button></span>`;
    }));

    ligarEventos();
    montarCubo();
  }

  function renderZona(zona, chips) {
    const el = $("zona" + zona.charAt(0).toUpperCase() + zona.slice(1));
    el.innerHTML = chips.length ? chips.join("") : `<span class="zona-vazia">arraste campos aqui</span>`;
  }

  /* ---------------- eventos (drag-and-drop + controles) ---------------- */
  function ligarEventos() {
    // palette: arrastar para adicionar
    $("zonaCampos").querySelectorAll(".palette").forEach((el) => {
      el.addEventListener("dragstart", (e) => {
        e.dataTransfer.setData("text/plain", JSON.stringify(
          { origem: "palette", campo: el.dataset.campo, papel: el.dataset.papel }));
      });
    });

    // chips das zonas: arrastar (mover/reordenar) e remover
    document.querySelectorAll("#viewCubo .zona.drop .chip").forEach((el) => {
      el.addEventListener("dragstart", (e) => {
        e.dataTransfer.setData("text/plain", JSON.stringify(
          { origem: el.dataset.zona, i: +el.dataset.i }));
      });
      el.querySelector(".chip-x")?.addEventListener("click", (e) => {
        e.stopPropagation();
        removerDaZona(el.dataset.zona, +el.dataset.i);
      });
      el.querySelector(".chip-edit")?.addEventListener("click", (e) => {
        e.stopPropagation();
        abrirCalc(+el.dataset.i);
      });
    });

    // seletor de agregacao
    $("zonaMetricas").querySelectorAll(".chip-agg").forEach((sel) => {
      sel.addEventListener("change", () => {
        state.zonas.metricas[+sel.dataset.i].agg = sel.value;
        montarCubo();
      });
    });

    // clique em chip de filtro abre o popup
    $("zonaFiltros").querySelectorAll(".chip").forEach((el) => {
      el.addEventListener("click", (e) => {
        if (e.target.classList.contains("chip-x")) return;
        abrirFiltro(+el.dataset.i);
      });
    });

    ligarZonasDrop();
  }

  // Alvos de "soltar" das 4 areas: ligados UMA UNICA VEZ. As caixas das areas
  // nao sao recriadas no redesenho; religa-las a cada acao acumularia ouvintes
  // (1 -> 2 -> 4 -> ...), multiplicando o trabalho e TRAVANDO o app.
  let zonasDropLigadas = false;
  function ligarZonasDrop() {
    if (zonasDropLigadas) return;
    zonasDropLigadas = true;
    document.querySelectorAll("#viewCubo .zona.drop").forEach((zel) => {
      zel.addEventListener("dragover", (e) => { e.preventDefault(); zel.classList.add("sobre"); });
      zel.addEventListener("dragleave", () => zel.classList.remove("sobre"));
      zel.addEventListener("drop", (e) => {
        e.preventDefault(); zel.classList.remove("sobre");
        let dados; try { dados = JSON.parse(e.dataTransfer.getData("text/plain")); } catch { return; }
        const alvoChip = e.target.closest(".chip");
        const idxAlvo = alvoChip ? +alvoChip.dataset.i : null;
        soltarNaZona(zel.dataset.zona, dados, idxAlvo);
      });
    });
  }

  function campoDe(dados) {
    if (dados.origem === "palette") return { campo: dados.campo, papel: dados.papel };
    const z = state.zonas[dados.origem];
    const it = z[dados.i];
    // Metrica calculada conta como "metrica" (para poder reordenar/arrastar).
    if (it && it.tipo === "calculada") return { campo: it.rotulo || "calculada", papel: "metrica", it };
    const campo = typeof it === "string" ? it : it.campo;
    return { campo, papel: state.mapa[campo] ? state.mapa[campo].papel : "dimensao", it };
  }

  function soltarNaZona(zona, dados, idxAlvo) {
    const info = campoDe(dados);
    const ehMetricaZona = zona === "metricas";
    if (ehMetricaZona && info.papel !== "metrica") { toast("Esta area aceita apenas metricas (campos numericos)."); return; }
    if (!ehMetricaZona && info.papel !== "dimensao") { toast("Esta area aceita apenas dimensoes."); return; }

    // remove da origem (se veio de uma zona)
    if (dados.origem !== "palette") removerDaZona(dados.origem, dados.i, true);

    if (zona === "metricas") {
      const nova = (dados.origem === "metricas" && dados.it) ? dados.it : { campo: info.campo, agg: "soma" };
      inserir(state.zonas.metricas, nova, idxAlvo);
    } else if (zona === "filtros") {
      // FILTRAR por um campo convive com ele estar em Linhas/Colunas: é como
      // dizer "quebre por vendedor, mas só mostre estes vendedores". Só evita
      // repetir o mesmo campo dentro de Filtros.
      if (!state.zonas.filtros.some((f) => f.campo === info.campo))
        inserir(state.zonas.filtros, { campo: info.campo, modo: "excluir", valores: [] }, idxAlvo);
    } else {
      // Linhas e Colunas são exclusivas ENTRE SI (um campo não é linha e coluna
      // ao mesmo tempo), mas não mexem no Filtro.
      const oposto = zona === "linhas" ? "colunas" : "linhas";
      state.zonas[oposto] = state.zonas[oposto].filter((c) => c !== info.campo);
      state.zonas[zona] = state.zonas[zona].filter((c) => c !== info.campo);
      inserir(state.zonas[zona], info.campo, idxAlvo);
    }
    sincronizar();
  }

  function inserir(arr, item, idx) {
    if (idx === null || idx === undefined || idx < 0 || idx > arr.length) arr.push(item);
    else arr.splice(idx, 0, item);
  }

  function removerDaZona(zona, i, silencioso) {
    state.zonas[zona].splice(i, 1);
    if (!silencioso) sincronizar();
  }

  /* ---------------- filtro (popup) ---------------- */
  function abrirFiltro(i) {
    const f = state.zonas.filtros[i];
    const campo = state.mapa[f.campo];
    const valores = (campo && campo.valores) || [];
    const excl = new Set(f.valores || []);
    const itens = valores.map((v) =>
      `<label class="fitem"><input type="checkbox" value="${esc(v)}" ${excl.has(v) ? "" : "checked"}> ${esc(v)}</label>`).join("");
    const aviso = campo && campo.muitos_valores ? `<p class="dica">Mostrando os primeiros valores.</p>` : "";
    const html = `<div class="modal-fundo" id="modalFiltro"><div class="modal">
      <h3>Filtrar: ${esc(f.campo)}</h3>${aviso}
      <div class="fbar"><button class="link" id="fTodos">Todos</button> · <button class="link" id="fNenhum">Nenhum</button></div>
      <div class="flista">${itens || '<span class="dica">sem valores</span>'}</div>
      <div class="modal-acoes"><button class="btn" id="fCancelar">Cancelar</button>
      <button class="btn primario" id="fAplicar">Aplicar</button></div></div></div>`;
    document.body.insertAdjacentHTML("beforeend", html);
    const fundo = $("modalFiltro");
    const marcar = (v) => fundo.querySelectorAll(".flista input").forEach((c) => (c.checked = v));
    $("fTodos").onclick = () => marcar(true);
    $("fNenhum").onclick = () => marcar(false);
    $("fCancelar").onclick = () => fundo.remove();
    fecharAoClicarFora(fundo, () => fundo.remove());
    $("fAplicar").onclick = () => {
      const excluidos = [];
      fundo.querySelectorAll(".flista input").forEach((c) => { if (!c.checked) excluidos.push(c.value); });
      f.valores = excluidos;
      fundo.remove();
      sincronizar();
    };
  }

  /* ---- metrica calculada: montador de FORMULA LIVRE ----------------------- */
  const AGG_CURTO = { soma: "Σ", media: "méd", contagem: "cont", contagem_distinta: "dist", minimo: "mín", maximo: "máx" };
  const OP_SIMB = { "+": "+", "-": "−", "*": "×", "/": "÷" };
  const OP_NOME_SIMB = { divisao: "/", multiplicacao: "*", soma: "+", subtracao: "-" };

  function formulaTexto(tokens) {
    return (tokens || []).map((tk) =>
      tk.t === "met" ? tk.campo
        : tk.t === "num" ? String(tk.v)
          : tk.t === "lpar" ? "("
            : tk.t === "rpar" ? ")"
              : (OP_SIMB[tk.v] || tk.v)
    ).join(" ").replace(/\(\s/g, "(").replace(/\s\)/g, ")");
  }

  // valida a sequencia de tokens (espelha o motor): parenteses equilibrados,
  // alternancia metrica/operador, nao terminar em operador, ter uma metrica.
  function validarFormula(tokens) {
    let espera = true, prof = 0, temMet = false;
    for (const tk of tokens) {
      if (tk.t === "met" || tk.t === "num") {
        if (!espera) return { ok: false, erro: "Falta um operador (+ − × ÷) entre os valores." };
        if (tk.t === "met") temMet = true;
        espera = false;
      } else if (tk.t === "op") {
        if (espera) { if (tk.v !== "-" && tk.v !== "+") return { ok: false, erro: "Coloque uma métrica ou número antes do operador." }; }
        else espera = true;
      } else if (tk.t === "lpar") {
        if (!espera) return { ok: false, erro: "Falta um operador antes do parêntese." };
        prof++; espera = true;
      } else if (tk.t === "rpar") {
        if (espera) return { ok: false, erro: "Parêntese fechado sem nada dentro." };
        if (prof === 0) return { ok: false, erro: "Há um parêntese a mais fechando." };
        prof--; espera = false;
      }
    }
    if (!tokens.length) return { ok: false, erro: "" };
    if (espera) return { ok: false, erro: "A fórmula está incompleta — falta um valor no fim." };
    if (prof > 0) return { ok: false, erro: "Falta fechar um parêntese." };
    if (!temMet) return { ok: false, erro: "Use ao menos uma métrica (os botões verdes)." };
    return { ok: true };
  }

  function tokenChip(tk, i) {
    if (tk.t === "met") {
      const ag = AGG_CURTO[tk.agg] || tk.agg;
      const nomeAgg = ((AGGS.find((a) => a[0] === tk.agg) || [])[1] || tk.agg).replace(/ \(.*/, "");
      return `<span class="ftok ftok-met" data-i="${i}" title="${esc(nomeAgg)} de ${esc(tk.campo)} — clique para remover"><b>${esc(ag)}</b>&nbsp;${esc(tk.campo)}</span>`;
    }
    if (tk.t === "num") return `<span class="ftok ftok-num" data-i="${i}" title="clique para remover">${esc(String(tk.v))}</span>`;
    if (tk.t === "lpar") return `<span class="ftok ftok-par" data-i="${i}" title="clique para remover">(</span>`;
    if (tk.t === "rpar") return `<span class="ftok ftok-par" data-i="${i}" title="clique para remover">)</span>`;
    return `<span class="ftok ftok-op" data-i="${i}" title="clique para remover">${esc(OP_SIMB[tk.v] || tk.v)}</span>`;
  }

  function abrirCalc(idx) {
    const mets = state.campos.filter((c) => c.papel === "metrica");
    if (!mets.length) { toast("Nenhum campo numérico (métrica) disponível para calcular."); return; }
    const atual = (idx != null && state.zonas.metricas[idx] && state.zonas.metricas[idx].tipo === "calculada")
      ? state.zonas.metricas[idx] : null;
    // tokens: da forma nova (formula) ou convertidos da forma simples antiga
    let tokens = atual && atual.formula ? atual.formula.map((t) => ({ ...t }))
      : (atual && atual.a
        ? [{ t: "met", campo: atual.a.campo, agg: atual.a.agg },
           { t: "op", v: OP_NOME_SIMB[atual.op] || "/" },
           { t: "met", campo: atual.b.campo, agg: atual.b.agg }]
        : []);
    const nome0 = atual ? (atual.rotulo || "") : "";
    const fmt0 = atual ? (atual.formato || "numero") : "numero";
    const campoOpts = mets.map((c) => `<option value="${esc(c.nome)}">${esc(c.nome)}</option>`).join("");
    const aggOpts = AGGS.map(([v, l]) => `<option value="${v}" ${v === "soma" ? "selected" : ""}>${esc(l)}</option>`).join("");

    const html = `<div class="modal-fundo" id="modalCalc"><div class="modal modal-calc">
      <h3>${atual ? "Editar" : "Nova"} métrica calculada</h3>
      <p class="dica">Monte a fórmula clicando nos botões — nada de digitar código. Ex.:
        <b>(Valor total − Custo) ÷ Quantidade × 100</b>. O cubo calcula em cada linha <i>e</i> no total
        (média ponderada).</p>
      <label class="cl-lab">Nome (vai no cabeçalho da coluna)
        <input type="text" id="clNome" placeholder="ex.: Preço médio" value="${esc(nome0)}"></label>
      <div class="cl-lab">Sua fórmula</div>
      <div class="cl-formula" id="clStrip"></div>
      <div class="cl-msg" id="clMsg"></div>
      <div class="cl-montar">
        <div class="cl-grp cl-grp-met">
          <select id="clAgg">${aggOpts}</select>
          <select id="clCampo">${campoOpts}</select>
          <button class="btn-ins btn-ins-met" id="clAddMet">+ métrica</button>
        </div>
        <div class="cl-grp">
          <button class="btn-op" data-op="+">+</button>
          <button class="btn-op" data-op="-">−</button>
          <button class="btn-op" data-op="*">×</button>
          <button class="btn-op" data-op="/">÷</button>
          <button class="btn-op" data-par="(">(</button>
          <button class="btn-op" data-par=")">)</button>
        </div>
        <div class="cl-grp">
          <input type="number" id="clNum" class="cl-num" placeholder="número" step="any">
          <button class="btn-ins" id="clAddNum">+ número</button>
          <button class="btn-op cl-del" id="clApaga" title="apagar o último">⌫</button>
          <button class="btn-op" id="clLimpa">limpar</button>
        </div>
      </div>
      <label class="cl-lab">Formato do resultado
        <select id="clFmt">
          <option value="numero" ${fmt0 === "numero" ? "selected" : ""}>Número (2 casas)</option>
          <option value="inteiro" ${fmt0 === "inteiro" ? "selected" : ""}>Inteiro</option>
        </select></label>
      <div class="modal-acoes"><button class="btn" id="clCancelar">Cancelar</button>
        <button class="btn primario" id="clAplicar">${atual ? "Salvar" : "Adicionar"}</button></div>
    </div></div>`;
    document.body.insertAdjacentHTML("beforeend", html);
    const fundo = $("modalCalc");

    function desenhar() {
      $("clStrip").innerHTML = tokens.length
        ? tokens.map((tk, i) => tokenChip(tk, i)).join("")
        : `<span class="cl-vazio">clique nos botões abaixo para montar…</span>`;
      const v = validarFormula(tokens);
      const msg = $("clMsg");
      if (!tokens.length) { msg.textContent = ""; msg.className = "cl-msg"; }
      else if (v.ok) { msg.textContent = "✓ " + formulaTexto(tokens); msg.className = "cl-msg ok"; }
      else { msg.textContent = "⚠ " + v.erro; msg.className = "cl-msg erro"; }
      $("clAplicar").disabled = !v.ok;
    }
    const push = (tk) => { tokens.push(tk); desenhar(); };

    $("clAddMet").onclick = () => push({ t: "met", campo: $("clCampo").value, agg: $("clAgg").value });
    $("clAddNum").onclick = () => {
      const n = parseFloat($("clNum").value);
      if (isNaN(n)) { toast("Digite um número primeiro."); return; }
      push({ t: "num", v: n }); $("clNum").value = "";
    };
    fundo.querySelectorAll(".btn-op[data-op]").forEach((b) => (b.onclick = () => push({ t: "op", v: b.dataset.op })));
    fundo.querySelectorAll(".btn-op[data-par]").forEach((b) => (b.onclick = () => push({ t: b.dataset.par === "(" ? "lpar" : "rpar" })));
    $("clApaga").onclick = () => { tokens.pop(); desenhar(); };
    $("clLimpa").onclick = () => { tokens = []; desenhar(); };
    $("clStrip").onclick = (e) => {
      const el = e.target.closest(".ftok");
      if (el) { tokens.splice(+el.dataset.i, 1); desenhar(); }
    };

    $("clCancelar").onclick = () => fundo.remove();
    fecharAoClicarFora(fundo, () => fundo.remove());
    $("clAplicar").onclick = () => {
      if (!validarFormula(tokens).ok) return;
      const item = {
        tipo: "calculada", formula: tokens.map((t) => ({ ...t })),
        rotulo: $("clNome").value.trim(), formato: $("clFmt").value,
      };
      if (idx != null) state.zonas.metricas[idx] = item;
      else state.zonas.metricas.push(item);
      fundo.remove();
      sincronizar();
    };
    desenhar();
  }

  /* ---------------- calcular (servidor) + render ---------------- */
  async function montarCubo() {
    if (!state.zonas.metricas.length) {
      $("cuboTabela").innerHTML = '<div class="vazio">Arraste ao menos uma <b>metrica</b> (campo numerico) para ver os resultados.</div>';
      $("cuboStatus").textContent = "";
      return;
    }
    const payload = {
      id: state.id, rows: state.zonas.linhas, cols: state.zonas.colunas,
      filtros: state.zonas.filtros, metricas: state.zonas.metricas, ordenacao: state.ordenacao,
    };
    $("loadingCubo").classList.remove("oculto");
    try {
      const r = await fetch("/api/cubo", {
        method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(payload),
      });
      const res = await r.json();
      if (!res.ok) {
        if (res.sessao_invalida && window.__voltarImport) { toast(res.erro); window.__voltarImport(); return; }
        $("cuboTabela").innerHTML = `<div class="vazio">${esc(res.erro || "Falha ao montar o cubo.")}</div>`;
        return;
      }
      state.ultimo = res;
      renderTabela(res);
      popularMetricas(res);
      if (!$("painelGrafico").classList.contains("oculto")) renderGrafico();
    } catch (e) { toast("Erro de comunicação ao montar o cubo: " + det(e)); }
    finally { $("loadingCubo").classList.add("oculto"); }
  }

  /* ---------------- grafico (Chart.js) ---------------- */
  function popularMetricas(res) {
    const sel = $("graficoMetrica");
    const atual = sel.value;
    sel.innerHTML = res.metricas.map((m, i) => `<option value="${i}">${esc(m.rotulo)}</option>`).join("");
    if (atual !== "" && +atual < res.metricas.length) sel.value = atual;
  }

  function renderGrafico() {
    const res = state.ultimo;
    const ctx = $("cuboCanvas");
    if (chartInst) { chartInst.destroy(); chartInst = null; }
    if (!res || !res.linhas.length) return;
    const tipo = $("graficoTipo").value;
    const mi = Math.min(+($("graficoMetrica").value || 0), res.metricas.length - 1);
    const dados = res.linhas.filter((l) => l.tipo === "dado");
    const cats = dados.map((l) => l.rotulos.filter(Boolean).join(" / ") || "(total)");

    if (tipo === "pie") {
      const valores = dados.map((l) => res.temTotalColuna ? (l.total ? l.total[mi] : 0) : (l.celulas[0] ? l.celulas[0][mi] : 0));
      chartInst = new Chart(ctx, {
        type: "pie",
        data: { labels: cats, datasets: [{ data: valores, backgroundColor: cats.map((_, i) => PALETA[i % PALETA.length]) }] },
        options: { responsive: true, maintainAspectRatio: false, plugins: { legend: { position: "right" } } },
      });
      return;
    }

    let datasets;
    if (res.cols.length) {
      datasets = res.colKeys.map((ck, ci) => ({ label: ck.join(" / "), data: dados.map((l) => l.celulas[ci] ? l.celulas[ci][mi] : null) }));
    } else {
      datasets = res.metricas.map((m, j) => ({ label: m.rotulo, data: dados.map((l) => l.celulas[0] ? l.celulas[0][j] : null) }));
    }
    const empilhado = tipo === "bar-stacked";
    const t = tipo === "line" ? "line" : "bar";
    chartInst = new Chart(ctx, {
      type: t,
      data: {
        labels: cats,
        datasets: datasets.map((d, i) => ({
          ...d, backgroundColor: PALETA[i % PALETA.length], borderColor: PALETA[i % PALETA.length],
          fill: false, tension: 0.2,
        })),
      },
      options: {
        responsive: true, maintainAspectRatio: false,
        plugins: { legend: { position: "bottom" } },
        scales: {
          x: { stacked: empilhado, ticks: { maxRotation: 60, minRotation: 0 } },
          y: { stacked: empilhado, ticks: { callback: (v) => fmtInt.format(v) } },
        },
      },
    });
  }

  function trocarAba(aba) {
    document.querySelectorAll(".result-abas .aba").forEach((b) => b.classList.toggle("ativa", b.dataset.aba === aba));
    $("painelTabela").classList.toggle("oculto", aba !== "tabela");
    $("painelGrafico").classList.toggle("oculto", aba !== "grafico");
    $("graficoCtrl").classList.toggle("oculto", aba !== "grafico");
    if (aba === "grafico") renderGrafico();
  }

  /* ---------------- exportar Excel ---------------- */
  async function exportarExcel() {
    if (!state.zonas.metricas.length) { toast("Adicione ao menos uma metrica antes de exportar."); return; }
    const payload = {
      id: state.id, rows: state.zonas.linhas, cols: state.zonas.colunas,
      filtros: state.zonas.filtros, metricas: state.zonas.metricas, ordenacao: state.ordenacao,
    };
    try {
      const r = await fetch("/api/exportar", {
        method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(payload),
      });
      if (!r.ok) { const j = await r.json().catch(() => ({})); toast(j.erro || "Falha ao exportar."); return; }
      const blob = await r.blob();

      // No app desktop: abre o "Salvar como" do Windows (escolhe NOME e PASTA)
      // e grava direto, devolvendo o caminho para a gente mostrar onde foi.
      const api = window.pywebview && window.pywebview.api && window.pywebview.api.salvar_excel;
      if (api) {
        const b64 = await new Promise((res, rej) => {
          const fr = new FileReader();
          fr.onload = () => res(String(fr.result).split(",", 2)[1]);
          fr.onerror = () => rej(new Error("Falha ao ler o arquivo gerado."));
          fr.readAsDataURL(blob);
        });
        const r2 = await window.pywebview.api.salvar_excel(b64, "cubo.xlsx");
        if (r2 && r2.ok) toast("Excel salvo em: " + r2.caminho);
        else if (r2 && r2.cancelado) { /* a pessoa cancelou — nao faz nada */ }
        else toast("Não foi possível salvar: " + ((r2 && r2.erro) || "erro desconhecido") + ".");
        return;
      }

      // Fora do app (navegador): baixa na pasta de Downloads do navegador.
      const a = document.createElement("a");
      a.href = URL.createObjectURL(blob); a.download = "cubo.xlsx";
      document.body.appendChild(a); a.click(); a.remove(); URL.revokeObjectURL(a.href);
      toast("Excel salvo na pasta de Downloads como “cubo.xlsx”.");
    } catch (e) { toast("Erro ao exportar Excel: " + det(e)); }
  }

  function corHeatmap(t) {
    // branco -> azul da marca, suave
    t = Math.max(0, Math.min(1, t));
    const r = Math.round(255 + (37 - 255) * t * 0.85);
    const g = Math.round(255 + (99 - 255) * t * 0.85);
    const b = Math.round(255 + (235 - 255) * t * 0.85);
    return `rgb(${r},${g},${b})`;
  }

  function celulaDado(valor, mi, res, barras, heatmap) {
    const formato = res.metricas[mi].formato;
    const esc_ = res.escala[mi] || {};
    let estilo = "", barra = "";
    if (valor !== null && valor !== undefined) {
      if (heatmap && esc_.max !== null && esc_.max !== esc_.min) {
        const t = (valor - esc_.min) / (esc_.max - esc_.min);
        estilo = ` style="background:${corHeatmap(t)}"`;
      } else if (barras && esc_.max) {
        const pct = Math.max(0, Math.min(100, (valor / esc_.max) * 100));
        barra = `<span class="cel-bar" style="width:${pct}%"></span>`;
      }
    }
    return `<td class="num"${estilo}>${barra}<span class="cel-val">${fmt(valor, formato)}</span></td>`;
  }

  function renderTabela(res) {
    const nm = res.metricas.length;
    const nr = res.rows.length;
    // Qtd. de colunas de rotulo de linha. O corpo SEMPRE usa pelo menos 1 (para
    // o "Total geral" quando nao ha dimensao em Linhas), entao o cabecalho tem
    // de reservar o mesmo tanto - senao os numeros escorregam uma coluna para a
    // direita e caem embaixo do cabecalho errado.
    const nlab = Math.max(1, nr);
    const temCol = res.cols.length > 0;
    const barras = $("chkBarras").checked;
    const heatmap = $("chkHeatmap").checked;
    const ord = state.ordenacao;
    // "ck" identifica a coluna do cabecalho: indice numerico da coluna, "total"
    // para a coluna Total, ou null quando nao ha colunas. A seta so aparece no
    // cabecalho exato (metrica + coluna) que esta ordenando.
    const mesmaCol = (ck) => (ck === null || ck === "")
      ? (ord.col === null || ord.col === undefined)
      : String(ord.col) === String(ck);
    const seta = (mi, ck) => (ord.por === mi && mesmaCol(ck)) ? (ord.direcao === "asc" ? " ▲" : " ▼") : "";
    const metHead = (ck) => res.metricas.map((m, mi) => {
      const dica = (m.descricao ? m.descricao + " " : "") + "(clique para ordenar por esta coluna)";
      return `<th class="met-h" data-mi="${mi}" data-ck="${ck === null ? "" : ck}" title="${esc(dica)}">`
        + `${esc(m.rotulo)}${seta(mi, ck)}</th>`;
    }).join("");

    // Cabecalhos das colunas de rotulo de linha (nomes das dimensoes, ou 1
    // celula vazia quando nao ha nenhuma - para casar com o "Total geral").
    const rdimHead = nr
      ? res.rows.map((r) => `<th class="rdim">${esc(r)}</th>`).join("")
      : `<th class="rdim"></th>`;

    let thead = "<thead>";
    if (temCol) {
      thead += "<tr>" + `<th class="corner" colspan="${nlab}"></th>` +
        res.colKeys.map((ck) => `<th class="colgrupo" colspan="${nm}">${esc(ck.join(" / "))}</th>`).join("") +
        (res.temTotalColuna ? `<th class="colgrupo total" colspan="${nm}">Total</th>` : "") + "</tr>";
      thead += "<tr>" + rdimHead +
        res.colKeys.map((_ck, ci) => metHead(ci)).join("") + (res.temTotalColuna ? metHead("total") : "") + "</tr>";
    } else {
      thead += "<tr>" + rdimHead + metHead(null) + "</tr>";
    }
    thead += "</thead>";

    let prevDado = null;
    const corpo = res.linhas.map((l) => {
      const cls = l.tipo === "dado" ? "" : (l.tipo === "subtotal" ? "subtotal" : "totalgeral");
      // rotulos de linha (com merge simples nos dados)
      let labs = "";
      for (let i = 0; i < nlab; i++) {
        let txt = l.rotulos[i] !== undefined ? l.rotulos[i] : "";
        if (l.tipo === "dado" && prevDado && txt && txt === prevDado[i] &&
            l.rotulos.slice(0, i + 1).join("\u0001") === prevDado.slice(0, i + 1).join("\u0001")) txt = "";
        labs += `<th class="rlab n${i}">${esc(txt)}</th>`;
      }
      if (l.tipo === "dado") prevDado = l.rotulos.slice(); else prevDado = null;

      let cels = "";
      res.colKeys.forEach((ck, ci) => {
        for (let mi = 0; mi < nm; mi++) {
          const v = l.celulas[ci] ? l.celulas[ci][mi] : null;
          cels += l.tipo === "dado" ? celulaDado(v, mi, res, barras, heatmap)
            : `<td class="num">${fmt(v, res.metricas[mi].formato)}</td>`;
        }
      });
      if (res.temTotalColuna) {
        for (let mi = 0; mi < nm; mi++) {
          const v = l.total ? l.total[mi] : null;
          cels += `<td class="num coltotal">${fmt(v, res.metricas[mi].formato)}</td>`;
        }
      }
      return `<tr class="${cls}">${labs}${cels}</tr>`;
    }).join("");

    $("cuboTabela").innerHTML = `<table class="cubo-tabela">${thead}<tbody>${corpo}</tbody></table>`;

    // ordenacao ao clicar numa metrica
    $("cuboTabela").querySelectorAll(".met-h").forEach((th) => {
      th.addEventListener("click", () => {
        const mi = +th.dataset.mi;
        const raw = th.dataset.ck;
        const ck = raw === "" ? null : (raw === "total" ? "total" : +raw);
        if (ord.por === mi && mesmaCol(ck)) ord.direcao = ord.direcao === "asc" ? "desc" : "asc";
        else { ord.por = mi; ord.col = ck; ord.direcao = "desc"; }
        montarCubo();
      });
    });

    const resumo = `Linhas: <b>${res.rows.join(", ") || "—"}</b> &nbsp;|&nbsp; Colunas: <b>${res.cols.join(", ") || "—"}</b>`
      + ` &nbsp;|&nbsp; Metricas: <b>${res.metricas.map((m) => m.rotulo).join(", ")}</b> &nbsp;|&nbsp; ${res.n_linhas_dados} grupos`;
    $("cuboStatus").innerHTML = resumo;
  }

  /* ---------------- exportar CSV ---------------- */
  function exportarCsv() {
    const t = document.querySelector("#cuboTabela table");
    if (!t) return;
    const linhas = [];
    t.querySelectorAll("tr").forEach((tr) => {
      const cel = [];
      tr.querySelectorAll("th,td").forEach((c) => {
        const txt = (c.querySelector(".cel-val") ? c.querySelector(".cel-val").innerText : c.innerText).replace(/\s+/g, " ").trim();
        cel.push('"' + txt.replace(/"/g, '""') + '"');
        for (let i = 1; i < (parseInt(c.getAttribute("colspan"), 10) || 1); i++) cel.push('""');
      });
      linhas.push(cel.join(";"));
    });
    const blob = new Blob(["﻿" + linhas.join("\r\n")], { type: "text/csv;charset=utf-8;" });
    const a = document.createElement("a");
    a.href = URL.createObjectURL(blob); a.download = "cubo_exportado.csv";
    document.body.appendChild(a); a.click(); a.remove(); URL.revokeObjectURL(a.href);
  }

  /* ---------------- helpers ---------------- */
  function esc(s) {
    return String(s).replace(/[&<>"]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]));
  }

  window.addEventListener("DOMContentLoaded", function () {
    // Cada binding e opcional (?.): se um elemento faltar (ex.: uma versao de
    // HTML fora de sincronia com este JS), a inicializacao NAO morre no meio e
    // o resto dos controles continua funcionando - o app nunca "trava" ao abrir.
    $("btnExemploCubo")?.addEventListener("click", () => { cenarioExemplo(); sincronizar(); });
    $("btnCalc")?.addEventListener("click", () => abrirCalc(null));
    $("btnSalvarCubo")?.addEventListener("click", salvarCubo);
    $("btnAbrirCubo")?.addEventListener("click", () => $("arqCubo")?.click());
    $("arqCubo")?.addEventListener("change", (e) => {
      const f = e.target.files[0];
      if (f) window.__abrirCubo(f);
      e.target.value = "";
    });
    $("btnAtualizarDados")?.addEventListener("click", atualizarDados);
    $("btnLimparCubo")?.addEventListener("click", () => {
      state.zonas = { filtros: [], colunas: [], linhas: [], metricas: [] };
      state.ordenacao = { por: "rotulo", direcao: "asc", col: null };
      sincronizar();
    });
    $("chkBarras")?.addEventListener("change", () => state.ultimo && renderTabela(state.ultimo));
    $("chkHeatmap")?.addEventListener("change", () => state.ultimo && renderTabela(state.ultimo));
    $("btnCsvCubo")?.addEventListener("click", exportarCsv);
    $("btnXlsxCubo")?.addEventListener("click", exportarExcel);
    document.querySelectorAll(".result-abas .aba").forEach((b) =>
      b.addEventListener("click", () => trocarAba(b.dataset.aba)));
    $("graficoTipo")?.addEventListener("change", renderGrafico);
    $("graficoMetrica")?.addEventListener("change", renderGrafico);
  });
})();
