@echo off
cd /d "%~dp0"
start "" "Avesso.exe" --navegador
