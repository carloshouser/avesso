/* Gerador de Cubos - Etapa 1 (importacao). Logica da interface. */
(function () {
  "use strict";

  const $ = (id) => document.getElementById(id);
  // origem dos dados em analise: {tipo:'csv'} (padrao) ou
  // {tipo:'mysql', conexao, sql}. Define o que o "Confirmar" vai enviar.
  const estado = { colunas: [], detectado: [], origem: { tipo: "csv" } };
  const NOME_MOTOR = { mysql: "MySQL", sqlserver: "SQL Server", postgres: "PostgreSQL" };
  const PORTA_PADRAO = { mysql: "3306", sqlserver: "1433", postgres: "5432" };

  /* ---------- utilitarios ---------- */
  function toast(msg) {
    const t = $("toast");
    t.textContent = msg;
    t.classList.add("show");
    clearTimeout(toast._t);
    toast._t = setTimeout(() => t.classList.remove("show"), 2600);
  }

  function temPywebview() {
    return !!(window.pywebview && window.pywebview.api && window.pywebview.api.escolher_arquivo);
  }

  function lerConfig() {
    // o valor "\t" vem do HTML como dois caracteres; converte para tab real
    let delim = $("delimitador").value;
    if (delim === "\\t") delim = "\t";
    return {
      caminho: $("caminho").value.trim(),
      delimitador: delim,
      decimal: $("decimal").value,
      milhares: $("milhares").value,
      codificacao: $("codificacao").value,
      tem_cabecalho: $("cabecalho").checked,
    };
  }

  function rotuloDelim(d) {
    return { ";": "Ponto e virgula", ",": "Virgula", "\t": "Tabulacao", "|": "Barra" }[d] || d;
  }

  /* ---------- selecao de arquivo ---------- */
  async function selecionarArquivo() {
    if (temPywebview()) {
      try {
        const caminho = await window.pywebview.api.escolher_arquivo();
        // Dá um instante para o WebView2 se recompor depois do diálogo nativo
        // (logo após fechar o seletor, a 1ª requisição às vezes falha).
        if (caminho) { $("caminho").value = caminho; setTimeout(analisar, 150); }
      } catch (e) { toast("Não foi possível abrir o seletor de arquivo: " + det(e)); }
    } else {
      // fora da janela desktop (ex.: navegador/teste): permite digitar o caminho
      const inp = $("caminho");
      inp.removeAttribute("readonly");
      inp.placeholder = "Cole aqui o caminho completo do arquivo .csv";
      inp.focus();
      toast("Cole o caminho do arquivo e clique em Analisar.");
    }
  }

  async function carregarExemplo() {
    try {
      const r = await fetch("/api/exemplo");
      const j = await r.json();
      if (j.ok && j.caminho) { $("caminho").value = j.caminho; analisar(); }
      else toast("Exemplo nao encontrado.");
    } catch (e) { toast("Falha ao carregar o exemplo: " + det(e)); }
  }

  // POST + JSON com UM reenvio automático: se a 1ª tentativa falhar na rede
  // (ex.: logo após o diálogo nativo, no WebView2), espera e tenta de novo.
  async function postJson(url, corpo) {
    let ultimoErro;
    for (let tentativa = 1; tentativa <= 2; tentativa++) {
      try {
        const r = await fetch(url, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(corpo),
        });
        return await r.json();
      } catch (e) {
        ultimoErro = e;
        if (tentativa < 2) await new Promise((s) => setTimeout(s, 350));
      }
    }
    throw ultimoErro;
  }

  /* ---------- analise ---------- */
  async function analisar() {
    const cfg = lerConfig();
    if (!cfg.caminho) { toast("Selecione um arquivo primeiro."); return; }
    estado.origem = { tipo: "csv" };   // analisar arquivo = fonte CSV
    $("btnAnalisar").disabled = true;
    $("btnAnalisar").textContent = "Analisando...";
    try {
      const res = await postJson("/api/analisar", cfg);
      if (!res.ok) { toast(res.erro || "Falha na importacao."); return; }
      renderResultado(res);
    } catch (e) {
      toast("Erro de comunicação com o servidor: " + det(e));
    } finally {
      $("btnAnalisar").disabled = false;
      $("btnAnalisar").textContent = "Analisar";
    }
  }

  /* ---------- renderizacao ---------- */
  function renderResultado(res) {
    $("estadoVazio").classList.add("oculto");
    ["secResumo", "secPreview", "secCampos"].forEach((s) => $(s).classList.remove("oculto"));

    // resumo (muda conforme a origem: arquivo CSV x consulta a um banco)
    const pills = res.origem === "banco"
      ? [
          ["Fonte", NOME_MOTOR[res.motor] || "Banco"],
          ["Banco", res.banco || "—"],
          ["Linhas", res.n_linhas.toLocaleString("pt-BR")],
          ["Colunas", res.n_colunas],
        ]
      : [
          ["Linhas", res.n_linhas.toLocaleString("pt-BR")],
          ["Colunas", res.n_colunas],
          ["Codificacao", res.codificacao],
          ["Delimitador", rotuloDelim(res.delimitador)],
          ["Decimal", res.decimal === "," ? "Virgula" : "Ponto"],
          ["Milhares", res.milhares || "Nenhum"],
        ];
    $("resumo").innerHTML = pills
      .map(([k, v]) => `<div class="pill"><div class="k">${k}</div><div class="v">${v}</div></div>`)
      .join("");

    // avisos
    const avisos = (res.avisos || []).slice();
    if (res.origem === "banco" && res.truncado) {
      avisos.push("A consulta trouxe muitas linhas; mostrando as primeiras " +
        (res.limite || 0).toLocaleString("pt-BR") + ". Refine com WHERE/LIMIT se precisar.");
    }
    $("avisos").innerHTML = avisos
      .map((a) => `<li>&#9888; ${escapar(a)}</li>`).join("");

    renderPreview(res);
    iniciarCampos(res.colunas);
  }

  function renderPreview(res) {
    const thead = "<thead><tr>" +
      res.colunas_preview.map((c) => `<th>${escapar(c)}</th>`).join("") + "</tr></thead>";
    const linhas = res.linhas_preview.map((linha) =>
      "<tr>" + linha.map((v) =>
        (v === null || v === undefined)
          ? '<td class="nulo">(vazio)</td>'
          : `<td>${escapar(String(v))}</td>`
      ).join("") + "</tr>"
    ).join("");
    $("preview").innerHTML = thead + "<tbody>" + linhas + "</tbody>";
  }

  const TIPOS = ["inteiro", "decimal", "data", "texto", "booleano"];
  const PAPEIS = [["dimensao", "Dimensao"], ["metrica", "Metrica"], ["ambos", "Ambos"]];

  function iniciarCampos(colunas) {
    // snapshot do que foi detectado (para "restaurar")
    estado.detectado = colunas.map((c) => ({
      nome_amigavel: c.nome_amigavel, tipo: c.tipo, papel: c.papel_sugerido,
    }));
    estado.colunas = colunas.map((c) => ({
      nome_original: c.nome_original,
      nome_amigavel: c.nome_amigavel,
      tipo: c.tipo,
      papel: c.papel_sugerido,
      exemplos: c.exemplos, n_vazios: c.n_vazios, n_distintos: c.n_distintos, total: c.total,
    }));
    renderCampos();
  }

  function renderCampos() {
    const cab = `<thead><tr>
      <th>Campo original</th><th>Nome de exibicao</th><th>Tipo</th><th>Papel</th>
      <th>Exemplos</th><th>Vazios</th><th>Distintos</th><th></th></tr></thead>`;

    const corpo = estado.colunas.map((c, i) => {
      const opTipo = TIPOS.map((t) =>
        `<option value="${t}" ${t === c.tipo ? "selected" : ""}>${cap(t)}</option>`).join("");
      const opPapel = PAPEIS.map(([v, lbl]) =>
        `<option value="${v}" ${v === c.papel ? "selected" : ""}>${lbl}</option>`).join("");
      const pct = c.total ? Math.round((c.n_vazios / c.total) * 100) : 0;
      return `<tr>
        <td><span class="orig">${escapar(c.nome_original)}</span></td>
        <td><input type="text" data-i="${i}" data-campo="nome_amigavel" value="${escapar(c.nome_amigavel)}"></td>
        <td><span class="badge ${c.tipo}" id="badge-${i}">${cap(c.tipo)}</span>
            <select data-i="${i}" data-campo="tipo" style="margin-top:4px;display:block">${opTipo}</select></td>
        <td><select data-i="${i}" data-campo="papel" class="papel-${c.papel}">${opPapel}</select></td>
        <td><span class="exemplos" title="${escapar(c.exemplos.join(' | '))}">${escapar(c.exemplos.join(', ')) || '—'}</span></td>
        <td>${c.n_vazios}${c.n_vazios ? ` <span style="color:var(--muted)">(${pct}%)</span>` : ''}</td>
        <td>${c.n_distintos}</td>
        <td><button class="link" data-restaurar="${i}">restaurar</button></td>
      </tr>`;
    }).join("");

    $("campos").innerHTML = cab + "<tbody>" + corpo + "</tbody>";

    // liga os eventos
    $("campos").querySelectorAll("input[data-campo],select[data-campo]").forEach((el) => {
      el.addEventListener("input", (e) => {
        const i = +e.target.dataset.i, campo = e.target.dataset.campo;
        estado.colunas[i][campo] = e.target.value;
        if (campo === "tipo") {
          const b = $("badge-" + i);
          b.className = "badge " + e.target.value;
          b.textContent = cap(e.target.value);
        }
        if (campo === "papel") e.target.className = "papel-" + e.target.value;
      });
    });
    $("campos").querySelectorAll("button[data-restaurar]").forEach((b) => {
      b.addEventListener("click", () => restaurarCampo(+b.dataset.restaurar));
    });
  }

  function restaurarCampo(i) {
    const d = estado.detectado[i];
    estado.colunas[i].nome_amigavel = d.nome_amigavel;
    estado.colunas[i].tipo = d.tipo;
    estado.colunas[i].papel = d.papel;
    renderCampos();
  }

  function restaurarTudo() {
    estado.colunas.forEach((c, i) => {
      const d = estado.detectado[i];
      c.nome_amigavel = d.nome_amigavel; c.tipo = d.tipo; c.papel = d.papel;
    });
    renderCampos();
    toast("Campos restaurados para o detectado.");
  }

  async function confirmar() {
    const esquema = estado.colunas.map((c) => ({
      nome_original: c.nome_original, nome_amigavel: c.nome_amigavel,
      tipo: c.tipo, papel: c.papel,
    }));
    window.CUBO_ESQUEMA = esquema;

    // Monta a "fonte" (de onde vieram os dados) e o corpo do /api/carregar,
    // conforme a origem. A fonte e salva no .cubo para recarregar/atualizar.
    let fonte, corpo;
    if (estado.origem.tipo === "banco") {
      const o = estado.origem;
      fonte = { tipo: "banco", motor: o.motor, conexao: o.conexao, sql: o.sql, esquema };
      corpo = { fonte_banco: { motor: o.motor, conexao: o.conexao, sql: o.sql }, esquema };
    } else {
      const cfg = lerConfig();
      fonte = { tipo: "csv", caminho: cfg.caminho, config: cfg, esquema };
      corpo = { caminho: cfg.caminho, config: cfg, esquema };
    }
    window.CUBO_FONTE = fonte;

    $("btnConfirmar").disabled = true;
    $("btnConfirmar").textContent = "Preparando cubo...";
    try {
      const r = await fetch("/api/carregar", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(corpo),
      });
      const res = await r.json();
      if (!res.ok) { toast(res.erro || "Falha ao preparar o cubo."); return; }
      irParaCubo(res);
    } catch (e) {
      toast("Erro ao preparar o cubo: " + det(e));
    } finally {
      $("btnConfirmar").disabled = false;
      $("btnConfirmar").textContent = "Confirmar campos";
    }
  }

  function irParaCubo(dados) {
    $("viewImport").classList.add("oculto");
    $("viewCubo").classList.remove("oculto");
    window.scrollTo(0, 0);
    window.iniciarCubo(dados, window.CUBO_FONTE);  // definido em cubo.js (id + campos + fonte)
  }

  function voltarParaImportacao() {
    $("viewCubo").classList.add("oculto");
    $("viewImport").classList.remove("oculto");
    window.scrollTo(0, 0);
  }

  /* ---------- conexao a um banco (nativa, sem ODBC): MySQL ou SQL Server ---------- */
  function lerMotor() { return $("myMotor").value; }
  // "windows" so vale para o SQL Server; nos demais casos = autenticacao por usuario/senha
  function lerAuth() { return lerMotor() === "sqlserver" ? $("myAuth").value : "sqlserver"; }
  function ehAuthWindows() { return lerAuth() === "windows"; }

  function lerConexao() {
    return {
      host: $("myHost").value.trim() || "127.0.0.1",
      porta: $("myPorta").value.trim(),
      auth: lerAuth(),
      usuario: $("myUser").value.trim(),
      senha: $("mySenha").value,
      banco: $("myBanco").value.trim(),
    };
  }

  function myStatus(msg, tipo) {
    const el = $("myStatus");
    el.className = "my-status" + (tipo ? " " + tipo : "");
    el.textContent = msg || "";
  }

  // Ao trocar o tipo de banco, ajusta a porta padrão (se o campo estiver vazio
  // ou ainda numa das portas padrão), a dica do campo Servidor e mostra a opção
  // de autenticação só quando for SQL Server.
  function aoTrocarMotor() {
    const motor = lerMotor();
    const porta = $("myPorta");
    // troca a porta se o campo estiver vazio ou ainda numa das portas padrão
    const padroes = Object.values(PORTA_PADRAO);
    if (!porta.value.trim() || padroes.includes(porta.value.trim())) {
      porta.value = PORTA_PADRAO[motor];
    }
    $("myHost").placeholder = motor === "sqlserver" ? "servidor  ou  servidor\\instancia" : "127.0.0.1";
    $("myAuthRow").style.display = motor === "sqlserver" ? "" : "none";
    aplicarAuth();
    myStatus("", "");
  }

  // Habilita Usuário/Senha só quando NÃO for Autenticação do Windows.
  function aplicarAuth() {
    const win = ehAuthWindows();
    [$("myUser"), $("mySenha")].forEach((el) => { el.disabled = win; });
    $("myUser").placeholder = win ? "(usa o login do Windows)" : "usuário";
    $("mySenha").placeholder = win ? "—" : "•••••";
  }

  async function testarBanco() {
    const motor = lerMotor(), conexao = lerConexao();
    if (!ehAuthWindows() && !conexao.usuario) { myStatus("Informe o usuário do banco.", "erro"); return; }
    $("myTestar").disabled = true;
    myStatus("Conectando…", "");
    try {
      const r = await fetch("/api/banco/testar", {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ motor, conexao }),
      });
      const res = await r.json();
      if (res.ok) myStatus("Conectado! " + res.versao + (res.banco ? " · banco “" + res.banco + "”" : ""), "ok");
      else myStatus("Não conectou: " + (res.erro || "erro desconhecido"), "erro");
    } catch (e) { myStatus("Erro de comunicação com o aplicativo: " + det(e), "erro"); }
    finally { $("myTestar").disabled = false; }
  }

  async function trazerBanco() {
    const motor = lerMotor(), conexao = lerConexao();
    const sql = $("mySql").value.trim();
    if (!ehAuthWindows() && !conexao.usuario) { myStatus("Informe o usuário do banco.", "erro"); return; }
    if (!sql) { myStatus("Escreva uma consulta SELECT.", "erro"); return; }
    $("myTrazer").disabled = true;
    myStatus("Executando a consulta…", "");
    try {
      const r = await fetch("/api/banco/consultar", {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ motor, conexao, sql }),
      });
      const res = await r.json();
      if (!res.ok) { myStatus("A consulta falhou: " + (res.erro || "erro desconhecido"), "erro"); return; }
      // guarda a origem (motor + conexao) para o Confirmar enviar ao /api/carregar
      estado.origem = { tipo: "banco", motor, conexao, sql };
      fecharBanco();
      renderResultado(res);                 // reaproveita a tela de campos
      toast("Consulta trouxe " + res.n_linhas.toLocaleString("pt-BR") + " registro(s). Confira os campos e confirme.");
      $("secCampos").scrollIntoView({ behavior: "smooth", block: "start" });
    } catch (e) { myStatus("Erro de comunicação com o aplicativo: " + det(e), "erro"); }
    finally { $("myTrazer").disabled = false; }
  }

  function fecharBanco() {
    const f = $("modalBanco");
    if (f) {
      if (f._onEsc) document.removeEventListener("keydown", f._onEsc);
      f.remove();
    }
  }

  function abrirBanco(prefill) {
    if ($("modalBanco")) return;            // ja aberto
    prefill = prefill || {};
    const motor = prefill.motor || "mysql";
    const auth = prefill.auth || "sqlserver";
    const opc = (v, lbl, sel) => `<option value="${v}" ${v === sel ? "selected" : ""}>${lbl}</option>`;
    const html = `<div class="modal-fundo" id="modalBanco"><div class="modal modal-banco">
      <h3>&#128279; Conectar a um banco de dados</h3>
      <p class="my-sub">Conexão <b>nativa</b>, sem ODBC. Escolha o banco, informe o servidor e escreva
      uma consulta <b>SELECT</b> — os registros entram direto no cubo.</p>
      <div class="my-grade">
        <label class="my-lab my-motor">Tipo de banco
          <select id="myMotor">${opc("mysql", "MySQL", motor)}${opc("sqlserver", "SQL Server", motor)}${opc("postgres", "PostgreSQL", motor)}</select>
        </label>
        <label class="my-lab">Servidor<input id="myHost" value="${escapar(prefill.host || "127.0.0.1")}" placeholder="127.0.0.1"></label>
        <label class="my-lab my-porta">Porta<input id="myPorta" value="${escapar(prefill.porta || PORTA_PADRAO[motor])}"></label>
        <label class="my-lab my-auth" id="myAuthRow">Tipo de autenticação
          <select id="myAuth">${opc("windows", "Autenticação do Windows", auth)}${opc("sqlserver", "Autenticação do SQL Server", auth)}</select>
        </label>
        <label class="my-lab">Usuário<input id="myUser" value="${escapar(prefill.usuario || "")}" placeholder="usuário"></label>
        <label class="my-lab">Senha<input id="mySenha" type="password" placeholder="•••••"></label>
        <label class="my-lab my-banco">Banco de dados<input id="myBanco" value="${escapar(prefill.banco || "")}" placeholder="nome_do_banco"></label>
      </div>
      <label class="my-lab my-sqllab">Consulta SQL <span class="my-hint">(somente leitura: SELECT, WITH, SHOW…)</span>
        <textarea id="mySql" rows="5" spellcheck="false" placeholder="SELECT * FROM venda">${escapar(prefill.sql || "")}</textarea>
      </label>
      <div class="my-status" id="myStatus"></div>
      <div class="modal-acoes">
        <button class="btn" id="myCancelar">Cancelar</button>
        <button class="btn" id="myTestar">Testar conexão</button>
        <button class="btn primario" id="myTrazer">Trazer para o cubo</button>
      </div>
    </div></div>`;
    document.body.insertAdjacentHTML("beforeend", html);
    const fundo = $("modalBanco");
    // Esta janela tem muitos campos (servidor, senha, SQL): NÃO fecha ao clicar
    // fora, para não perder tudo por um clique no fundo sem querer. Fecha só pelo
    // botão Cancelar ou pela tecla Esc.
    fundo._onEsc = (e) => { if (e.key === "Escape") fecharBanco(); };
    document.addEventListener("keydown", fundo._onEsc);
    $("myMotor").onchange = aoTrocarMotor;
    $("myAuth").onchange = () => { aplicarAuth(); myStatus("", ""); };
    $("myCancelar").onclick = fecharBanco;
    $("myTestar").onclick = testarBanco;
    $("myTrazer").onclick = trazerBanco;
    aoTrocarMotor();                        // ajusta porta/dica/autenticacao conforme o motor
    (prefill.usuario ? $("mySenha") : $("myHost")).focus();
  }

  /* ---------- helpers de texto ---------- */
  function escapar(s) {
    return String(s).replace(/[&<>"]/g, (c) =>
      ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]));
  }
  function cap(s) { return s ? s.charAt(0).toUpperCase() + s.slice(1) : s; }
  // Mensagem real de um erro (para sempre mostrar o que aconteceu).
  function det(e) { return e && e.message ? e.message : String(e); }

  /* ---------- trial (versao de avaliacao) ---------- */
  async function verificarTrial() {
    let st;
    try { st = await (await fetch("/api/trial")).json(); }
    catch (e) { return; }                 // se nao der para checar, nao bloqueia
    if (!st || !st.ativo) return;          // modo desenvolvimento: sem trial
    if (st.ok) {
      if (st.dias <= 7) mostrarBannerTrial(st.dias);
      return;
    }
    mostrarAtivacao(st);                   // expirado / outra maquina / relogio
  }

  function mostrarBannerTrial(dias) {
    const txt = dias <= 0 ? "último dia de teste"
      : (dias === 1 ? "falta 1 dia de teste" : "faltam " + dias + " dias de teste");
    const b = document.createElement("div");
    b.className = "trial-banner" + (dias <= 3 ? " urgente" : "");
    b.innerHTML = "🕒 Versão de avaliação — " + txt + ".";
    // Faixa no TOPO, ACIMA do cabecalho (nunca por cima da logo).
    document.body.insertBefore(b, document.body.firstChild);
  }

  function mostrarAtivacao(st) {
    const titulos = { expirou: "Período de avaliação encerrado",
                      maquina: "Cópia não autorizada neste computador",
                      relogio: "Relógio do computador alterado" };
    const msgs = {
      expirou: "O seu período de avaliação chegou ao fim. Para continuar usando o Avesso, ative com uma chave.",
      maquina: "Esta cópia foi ativada em outro computador e, por isso, não funciona aqui. Peça uma chave para este computador.",
      relogio: "O relógio do computador parece ter sido atrasado. Acerte a data e a hora e abra o Avesso de novo." };
    const html = `<div class="trial-fundo" id="trialFundo"><div class="trial-caixa">
      <img class="trial-logo" src="img/avesso-icone.png" alt="Avesso">
      <h2>${titulos[st.motivo] || "Ativação necessária"}</h2>
      <p>${msgs[st.motivo] || ""}</p>
      <div class="trial-cod"><span>Código da sua máquina</span><b id="trialCod">${escapar(st.codigo_maquina || "")}</b></div>
      <p class="trial-sub">Informe o código acima ao desenvolvedor, receba a <b>chave de ativação</b> e cole-a aqui:</p>
      <div class="trial-form">
        <input id="trialChave" placeholder="AVS-XXXX-XXXX-XXXX-XXXX-XXXX" autocomplete="off" spellcheck="false">
        <button class="btn primario" id="trialAtivar">Ativar</button>
      </div>
      <div class="trial-msg" id="trialMsg"></div>
    </div></div>`;
    document.body.insertAdjacentHTML("beforeend", html);
    $("trialAtivar").onclick = ativarTrial;
    $("trialChave").addEventListener("keydown", (e) => { if (e.key === "Enter") ativarTrial(); });
    $("trialChave").focus();
  }

  async function ativarTrial() {
    const chave = $("trialChave").value.trim();
    const msg = $("trialMsg");
    if (!chave) { msg.className = "trial-msg erro"; msg.textContent = "Cole a chave de ativação."; return; }
    $("trialAtivar").disabled = true;
    try {
      const r = await (await fetch("/api/ativar", {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ chave }),
      })).json();
      if (r.ok) {
        msg.className = "trial-msg ok";
        msg.textContent = "Ativado! Liberado por mais " + r.dias + " dias. Abrindo…";
        setTimeout(() => location.reload(), 1300);
      } else {
        msg.className = "trial-msg erro";
        msg.textContent = r.erro || "Não foi possível ativar.";
      }
    } catch (e) {
      msg.className = "trial-msg erro";
      msg.textContent = "Erro ao ativar: " + det(e);
    } finally {
      $("trialAtivar").disabled = false;
    }
  }

  // expoe utilitarios para o cubo.js
  window.__toast = toast;
  window.__voltarImport = voltarParaImportacao;
  window.__abrirBanco = abrirBanco;

  /* ---------- ligacao inicial ---------- */
  window.addEventListener("DOMContentLoaded", () => {
    verificarTrial();   // checa a versao de avaliacao (so age no .exe)
    $("btnArquivo").addEventListener("click", selecionarArquivo);
    $("btnExemplo").addEventListener("click", carregarExemplo);
    $("btnBanco").addEventListener("click", () => abrirBanco());
    $("btnAnalisar").addEventListener("click", analisar);
    $("btnConfirmar").addEventListener("click", confirmar);
    $("btnRestaurarTudo").addEventListener("click", restaurarTudo);
    $("btnVoltar").addEventListener("click", voltarParaImportacao);
    // abrir um cubo salvo direto da tela de importacao (a logica mora no cubo.js)
    $("btnAbrirCuboImport")?.addEventListener("click", () => $("arqCuboImport")?.click());
    $("arqCuboImport")?.addEventListener("change", (e) => {
      const f = e.target.files[0];
      if (f && window.__abrirCubo) window.__abrirCubo(f);
      e.target.value = "";
    });
  });
})();
